

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var _0x0295 = ["split", "BIGNF", "length", "PxMzv", "fromCharCode", "XMJZt", "Uknst", "indexOf", "charAt", "IgrAi", "isrQD", "NrFxr", "Bfusx", "EGuje", "RTbDl", "skTIa", "tPROO", "EyCRq", "replace", "reverse", "NcOIe", "4|6|5|0|7|3|2|1|8", "6|2|9|8|5|4|7|10|0|3|1", "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=", "WSNWx"];
(function (_0x49bd0e, _0x12b3c1) {
  var _0x43d5c3 = function _0x43d5c3(_0x5ed13b) {
    while (--_0x5ed13b) {
      _0x49bd0e["push"](_0x49bd0e["shift"]());
    }
  };
  _0x43d5c3(++_0x12b3c1);
})(_0x0295, 0x1f0);
var _0x5029 = function _0x5029(_0x311c35, _0x534915) {
  _0x311c35 = _0x311c35 - 0x0;
  var _0x5cc50c = _0x0295[_0x311c35];
  return _0x5cc50c;
};
var k;
var d = function d(_0x5ecd00, _0x184b8d) {
  var _0x388cca = {
    WSNWx: _0x5029("0x0"),
    BIGNF: function _0x4a2ce8(_0x269406, _0x73c036) {
      return _0x269406 < _0x73c036;
    },
    PxMzv: _0x5029("0x1"),
    Uknst: function _0x5b25b8(_0x5f561b, _0x7441d8) {
      return _0x5f561b + _0x7441d8;
    },
    XMJZt: function _0x60440f(_0x99a9bc, _0x219b5d) {
      return _0x99a9bc != _0x219b5d;
    },
    IgrAi: function _0x46be5a(_0x2ee3bb, _0x403ad9) {
      return _0x2ee3bb != _0x403ad9;
    },
    WrqtH: function _0x2eccdf(_0x2b036d, _0x5d7139) {
      return _0x2b036d + _0x5d7139;
    },
    isrQD: function _0x4bf5cf(_0x44ec17, _0x413f9e) {
      return _0x44ec17 | _0x413f9e;
    },
    NrFxr: function _0xf51086(_0x15906f, _0x2d8c9a) {
      return _0x15906f << _0x2d8c9a;
    },
    Bfusx: function _0x3f5115(_0x459230, _0x5f166a) {
      return _0x459230 & _0x5f166a;
    },
    EGuje: function _0x31a1fd(_0x3a0d6f, _0xc1be70) {
      return _0x3a0d6f >> _0xc1be70;
    },
    RTbDl: function _0x4b61a6(_0x3bf700, _0x3d3525) {
      return _0x3bf700 | _0x3d3525;
    },
    skTIa: function _0x2c54eb(_0x51c6d0, _0x331271) {
      return _0x51c6d0 << _0x331271;
    },
    tPROO: function _0x1dadd1(_0x343c0a, _0x50af55) {
      return _0x343c0a & _0x50af55;
    },
    EyCRq: function _0xfcdaa4(_0x145616, _0x5a35bc) {
      return _0x145616 ^ _0x5a35bc;
    },
    NcOIe: _0x5029("0x2")
  };
  var _0x42d795 = _0x388cca[_0x5029("0x3")][_0x5029("0x4")]("|"),
      _0x3f3118 = 0x0;
  while (!![]) {
    switch (_0x42d795[_0x3f3118++]) {
      case "0":
        var _0x4a2f3a, _0x29d5bf, _0x3b6833, _0x426d70;
        continue;
      case "1":
        while (_0x388cca[_0x5029("0x5")](_0x1598e0, _0x5ecd00[_0x5029("0x6")])) {
          var _0x5e7f50 = _0x388cca[_0x5029("0x7")][_0x5029("0x4")]("|"),
              _0x455464 = 0x0;
          while (!![]) {
            switch (_0x5e7f50[_0x455464++]) {
              case "0":
                _0x59b81a = _0x388cca["Uknst"](_0x59b81a, String[_0x5029("0x8")](_0x2e4782));
                continue;
              case "1":
                if (_0x388cca[_0x5029("0x9")](_0x426d70, 0x40)) {
                  _0x59b81a = _0x388cca[_0x5029("0xa")](_0x59b81a, String[_0x5029("0x8")](_0x5a46ef));
                }
                continue;
              case "2":
                _0x29d5bf = k[_0x5029("0xb")](_0x5ecd00[_0x5029("0xc")](_0x1598e0++));
                continue;
              case "3":
                if (_0x388cca[_0x5029("0xd")](_0x3b6833, 0x40)) {
                  _0x59b81a = _0x388cca["WrqtH"](_0x59b81a, String[_0x5029("0x8")](_0x2c0540));
                }
                continue;
              case "4":
                _0x2c0540 = _0x388cca[_0x5029("0xe")](_0x388cca[_0x5029("0xf")](_0x388cca[_0x5029("0x10")](_0x29d5bf, 0xf), 0x4), _0x388cca[_0x5029("0x11")](_0x3b6833, 0x2));
                continue;
              case "5":
                _0x2e4782 = _0x388cca[_0x5029("0x12")](_0x388cca[_0x5029("0xf")](_0x4a2f3a, 0x2), _0x388cca[_0x5029("0x11")](_0x29d5bf, 0x4));
                continue;
              case "6":
                _0x4a2f3a = k[_0x5029("0xb")](_0x5ecd00["charAt"](_0x1598e0++));
                continue;
              case "7":
                _0x5a46ef = _0x388cca[_0x5029("0x13")](_0x388cca[_0x5029("0x14")](_0x3b6833, 0x3), 0x6) | _0x426d70;
                continue;
              case "8":
                _0x426d70 = k["indexOf"](_0x5ecd00["charAt"](_0x1598e0++));
                continue;
              case "9":
                _0x3b6833 = k["indexOf"](_0x5ecd00[_0x5029("0xc")](_0x1598e0++));
                continue;
              case "10":
                _0x2e4782 = _0x388cca[_0x5029("0x15")](_0x2e4782, _0x184b8d);
                continue;
            }
            break;
          }
        }
        continue;
      case "2":
        _0x5ecd00 = _0x5ecd00[_0x5029("0x16")](/[^A-Za-z0-9\+\/\=]/g, "");
        continue;
      case "3":
        k = k[_0x5029("0x4")]("")[_0x5029("0x17")]()["join"]("");
        continue;
      case "4":
        k = _0x388cca[_0x5029("0x18")];
        continue;
      case "5":
        var _0x2e4782, _0x2c0540, _0x5a46ef;
        continue;
      case "6":
        var _0x59b81a = "";
        continue;
      case "7":
        var _0x1598e0 = 0x0;
        continue;
      case "8":
        return _0x59b81a;
        continue;
    }
    break;
  }
};

var Streamango = function () {
  function Streamango(props) {
    _classCallCheck(this, Streamango);

    this.libs = props.libs;
    this.settings = props.settings;
    this.state = {};
  }

  _createClass(Streamango, [{
    key: "getQuality",
    value: function getQuality(url) {
      var qualities = ['CAM', 'DVDRip', 'HDTV', 'HDRip', 'WEB-DL', 'WEBRip', 'BRRip', 'Blu-ray', 'BDRip', 'WEB', 'HDTS', 'TS'];

      for (var i in qualities) {
        var quality = qualities[i];
        if (url.toLowerCase().indexOf(quality.toLowerCase()) != -1) {
          return quality;
        }
      }

      return false;
    }
  }, {
    key: "checkLive",
    value: function () {
      var _ref = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(url) {
        var httpRequest, html;
        return regeneratorRuntime.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                if (!(url.indexOf('http://') != 0 && url.indexOf('https://') != 0)) {
                  _context.next = 2;
                  break;
                }

                throw new Error('NOT_FOUND');

              case 2:
                httpRequest = this.libs.httpRequest;

                // you fill the die status text
                // const dieStatusText = "";

                _context.prev = 3;
                _context.next = 6;
                return httpRequest.getHTML(url);

              case 6:
                html = _context.sent;
                _context.next = 12;
                break;

              case 9:
                _context.prev = 9;
                _context.t0 = _context["catch"](3);
                throw new Error('NOT_FOUND');

              case 12:
                return _context.abrupt("return", html);

              case 13:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, this, [[3, 9]]);
      }));

      function checkLive(_x) {
        return _ref.apply(this, arguments);
      }

      return checkLive;
    }()
  }, {
    key: "getLink",
    value: function () {
      var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee3(url) {
        var _this = this;

        var _libs, httpRequest, cheerio, html, $, targetedScriptString, reg, matchArr, sources, srces, resultArr, arrPromise;

        return regeneratorRuntime.wrap(function _callee3$(_context3) {
          while (1) {
            switch (_context3.prev = _context3.next) {
              case 0:
                if (!(url.indexOf('http://') != 0 && url.indexOf('https://') != 0)) {
                  _context3.next = 2;
                  break;
                }

                throw new Error('NOT_FOUND');

              case 2:
                _libs = this.libs, httpRequest = _libs.httpRequest, cheerio = _libs.cheerio;
                _context3.next = 5;
                return this.checkLive(url);

              case 5:
                html = _context3.sent;

                if (!(html == false)) {
                  _context3.next = 8;
                  break;
                }

                throw new Error("LINK DIE");

              case 8:
                $ = cheerio.load(html);
                targetedScriptString = $('script:contains("var srces")').html();

                if (!(targetedScriptString == null)) {
                  _context3.next = 12;
                  break;
                }

                throw new Error("ERROR GET LINK STREAMANGO - " + url);

              case 12:
                reg = /srces.push *\( *{ *type *: *"video\/mp4"(.*);/g;
                matchArr = targetedScriptString.match(reg);

                if (!(matchArr == null)) {
                  _context3.next = 16;
                  break;
                }

                throw new Error("ERROR GET LINK STREAMANGO 1");

              case 16:
                sources = [];
                srces = [];


                matchArr.forEach(function (val, index) {
                  eval(val);
                });

                resultArr = srces.map(function (val, index) {
                  var quality = _this.getQuality(url);
                  var s = {
                    file: "https:" + val.src,
                    label: val.height + "p",
                    type: "direct"
                  };

                  if (quality) s.source_label = quality;
                  return s;
                });
                arrPromise = resultArr.map(function () {
                  var _ref3 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2(val) {
                    var isDie;
                    return regeneratorRuntime.wrap(function _callee2$(_context2) {
                      while (1) {
                        switch (_context2.prev = _context2.next) {
                          case 0:
                            _context2.next = 2;
                            return httpRequest.isLinkDie(val.file);

                          case 2:
                            isDie = _context2.sent;


                            if (isDie != false) {
                              val.size = isDie;
                              sources.push(val);
                            }

                          case 4:
                          case "end":
                            return _context2.stop();
                        }
                      }
                    }, _callee2, this);
                  }));

                  return function (_x3) {
                    return _ref3.apply(this, arguments);
                  };
                }());
                _context3.next = 23;
                return Promise.all(arrPromise);

              case 23:
                return _context3.abrupt("return", {
                  host: {
                    url: url,
                    name: "streamango"
                  },
                  result: resultArr
                });

              case 24:
              case "end":
                return _context3.stop();
            }
          }
        }, _callee3, this);
      }));

      function getLink(_x2) {
        return _ref2.apply(this, arguments);
      }

      return getLink;
    }()
  }]);

  return Streamango;
}();

thisSource.function = function (libs, settings) {
  return new Streamango({ libs: libs, settings: settings });
};