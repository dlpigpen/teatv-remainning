var _0x0295 = [
    "split",
    "BIGNF",
    "length",
    "PxMzv",
    "fromCharCode",
    "XMJZt",
    "Uknst",
    "indexOf",
    "charAt",
    "IgrAi",
    "isrQD",
    "NrFxr",
    "Bfusx",
    "EGuje",
    "RTbDl",
    "skTIa",
    "tPROO",
    "EyCRq",
    "replace",
    "reverse",
    "NcOIe",
    "4|6|5|0|7|3|2|1|8",
    "6|2|9|8|5|4|7|10|0|3|1",
    "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",
    "WSNWx"
  ];
  (function(_0x49bd0e, _0x12b3c1) {
    var _0x43d5c3 = function(_0x5ed13b) {
      while (--_0x5ed13b) {
        _0x49bd0e["push"](_0x49bd0e["shift"]());
      }
    };
    _0x43d5c3(++_0x12b3c1);
  })(_0x0295, 0x1f0);
  var _0x5029 = function(_0x311c35, _0x534915) {
    _0x311c35 = _0x311c35 - 0x0;
    var _0x5cc50c = _0x0295[_0x311c35];
    return _0x5cc50c;
  };
  var k;
  var d = function(_0x5ecd00, _0x184b8d) {
    var _0x388cca = {
      WSNWx: _0x5029("0x0"),
      BIGNF: function _0x4a2ce8(_0x269406, _0x73c036) {
        return _0x269406 < _0x73c036;
      },
      PxMzv: _0x5029("0x1"),
      Uknst: function _0x5b25b8(_0x5f561b, _0x7441d8) {
        return _0x5f561b + _0x7441d8;
      },
      XMJZt: function _0x60440f(_0x99a9bc, _0x219b5d) {
        return _0x99a9bc != _0x219b5d;
      },
      IgrAi: function _0x46be5a(_0x2ee3bb, _0x403ad9) {
        return _0x2ee3bb != _0x403ad9;
      },
      WrqtH: function _0x2eccdf(_0x2b036d, _0x5d7139) {
        return _0x2b036d + _0x5d7139;
      },
      isrQD: function _0x4bf5cf(_0x44ec17, _0x413f9e) {
        return _0x44ec17 | _0x413f9e;
      },
      NrFxr: function _0xf51086(_0x15906f, _0x2d8c9a) {
        return _0x15906f << _0x2d8c9a;
      },
      Bfusx: function _0x3f5115(_0x459230, _0x5f166a) {
        return _0x459230 & _0x5f166a;
      },
      EGuje: function _0x31a1fd(_0x3a0d6f, _0xc1be70) {
        return _0x3a0d6f >> _0xc1be70;
      },
      RTbDl: function _0x4b61a6(_0x3bf700, _0x3d3525) {
        return _0x3bf700 | _0x3d3525;
      },
      skTIa: function _0x2c54eb(_0x51c6d0, _0x331271) {
        return _0x51c6d0 << _0x331271;
      },
      tPROO: function _0x1dadd1(_0x343c0a, _0x50af55) {
        return _0x343c0a & _0x50af55;
      },
      EyCRq: function _0xfcdaa4(_0x145616, _0x5a35bc) {
        return _0x145616 ^ _0x5a35bc;
      },
      NcOIe: _0x5029("0x2")
    };
    var _0x42d795 = _0x388cca[_0x5029("0x3")][_0x5029("0x4")]("|"),
      _0x3f3118 = 0x0;
    while (!![]) {
      switch (_0x42d795[_0x3f3118++]) {
        case "0":
          var _0x4a2f3a, _0x29d5bf, _0x3b6833, _0x426d70;
          continue;
        case "1":
          while (
            _0x388cca[_0x5029("0x5")](_0x1598e0, _0x5ecd00[_0x5029("0x6")])
          ) {
            var _0x5e7f50 = _0x388cca[_0x5029("0x7")][_0x5029("0x4")]("|"),
              _0x455464 = 0x0;
            while (!![]) {
              switch (_0x5e7f50[_0x455464++]) {
                case "0":
                  _0x59b81a = _0x388cca["Uknst"](
                    _0x59b81a,
                    String[_0x5029("0x8")](_0x2e4782)
                  );
                  continue;
                case "1":
                  if (_0x388cca[_0x5029("0x9")](_0x426d70, 0x40)) {
                    _0x59b81a = _0x388cca[_0x5029("0xa")](
                      _0x59b81a,
                      String[_0x5029("0x8")](_0x5a46ef)
                    );
                  }
                  continue;
                case "2":
                  _0x29d5bf = k[_0x5029("0xb")](
                    _0x5ecd00[_0x5029("0xc")](_0x1598e0++)
                  );
                  continue;
                case "3":
                  if (_0x388cca[_0x5029("0xd")](_0x3b6833, 0x40)) {
                    _0x59b81a = _0x388cca["WrqtH"](
                      _0x59b81a,
                      String[_0x5029("0x8")](_0x2c0540)
                    );
                  }
                  continue;
                case "4":
                  _0x2c0540 = _0x388cca[_0x5029("0xe")](
                    _0x388cca[_0x5029("0xf")](
                      _0x388cca[_0x5029("0x10")](_0x29d5bf, 0xf),
                      0x4
                    ),
                    _0x388cca[_0x5029("0x11")](_0x3b6833, 0x2)
                  );
                  continue;
                case "5":
                  _0x2e4782 = _0x388cca[_0x5029("0x12")](
                    _0x388cca[_0x5029("0xf")](_0x4a2f3a, 0x2),
                    _0x388cca[_0x5029("0x11")](_0x29d5bf, 0x4)
                  );
                  continue;
                case "6":
                  _0x4a2f3a = k[_0x5029("0xb")](_0x5ecd00["charAt"](_0x1598e0++));
                  continue;
                case "7":
                  _0x5a46ef =
                    _0x388cca[_0x5029("0x13")](
                      _0x388cca[_0x5029("0x14")](_0x3b6833, 0x3),
                      0x6
                    ) | _0x426d70;
                  continue;
                case "8":
                  _0x426d70 = k["indexOf"](_0x5ecd00["charAt"](_0x1598e0++));
                  continue;
                case "9":
                  _0x3b6833 = k["indexOf"](
                    _0x5ecd00[_0x5029("0xc")](_0x1598e0++)
                  );
                  continue;
                case "10":
                  _0x2e4782 = _0x388cca[_0x5029("0x15")](_0x2e4782, _0x184b8d);
                  continue;
              }
              break;
            }
          }
          continue;
        case "2":
          _0x5ecd00 = _0x5ecd00[_0x5029("0x16")](/[^A-Za-z0-9\+\/\=]/g, "");
          continue;
        case "3":
          k = k[_0x5029("0x4")]("")
            [_0x5029("0x17")]()
            ["join"]("");
          continue;
        case "4":
          k = _0x388cca[_0x5029("0x18")];
          continue;
        case "5":
          var _0x2e4782, _0x2c0540, _0x5a46ef;
          continue;
        case "6":
          var _0x59b81a = "";
          continue;
        case "7":
          var _0x1598e0 = 0x0;
          continue;
        case "8":
          return _0x59b81a;
          continue;
      }
      break;
    }
  };

  


class Streamango {

  constructor(props) {

      this.libs     = props.libs;
      this.settings = props.settings;
      this.state    = {};
  }


  async checkLive(url) {

    let { httpRequest } = this.libs;

    // you fill the die status text
    // const dieStatusText = "";
    let html = await httpRequest.getHTML(url);
    // if(html.includes(dieStatusText)) return true;
    return html;
  }

  async getLink(url) {

    let { httpRequest, cheerio }  = this.libs;
    let html                      = await this.checkLive(url);

    if( html == false ) throw new Error("LINK DIE");

    let $                     = cheerio.load(html);
    let targetedScriptString  = $('script:contains("var srces")').html();
    
    if (targetedScriptString == null) throw new Error("ERROR GET LINK STREAMANGO");
    
    let reg       = /srces.push\({type:"video\/mp4"(.*);/g;
    let matchArr  = targetedScriptString.match(reg);

    if (matchArr == null) throw new Error("ERROR GET LINK STREAMANGO");

    let sources = [];
    let srces   = [];

    matchArr.forEach((val, index) => {
        eval(val);
    });
    
    let resultArr = srces.map((val, index) => {
        let quality = this.getQuality(url);
        return {
            file: "https:" + val.src,
            label: quality?quality:val.height + "p",
            type: "direct"
        };
    });

    let arrPromise = resultArr.map(async function(val) {

      let isDie = await httpRequest.isLinkDie(val.file);

      if( isDie != false ) {
        val.size = isDie;
        sources.push(val);
      }
    });

    await Promise.all(arrPromise);

    return { 
      host: {
          url: url,
          name: "streamango"
      },
      result: resultArr
    };
  }
}


exports.default = (libs, settings) => new Streamango({ libs, settings });